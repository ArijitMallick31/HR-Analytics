
# HR Analytics Dashboard

This project is a Power BI-based HR Analytics dashboard developed to monitor and analyze employee presence, Work From Home (WFH) trends, and sick leave patterns across various dates and employees.

## 📊 Dashboard Features

- **Total Working Days** and **Presence %**
- **WFH %** and **Sick Leave %**
- Interactive breakdowns by:
  - Employee Name
  - Date
  - Day of the Week
- Time-series charts showing daily trends

## 🛠 Tools Used

- Power BI
- Microsoft Excel / CSV
- Data Cleaning and Transformation

## 📁 Project Structure

```
HR-Analytics-Dashboard/
├── HR_Anlt.pbix                     ← Power BI report
├── Cleaned_HR_Data_Analysis.csv    ← Cleaned dataset
├── README.md                       ← Project description
└── screenshots/                    ← Dashboard images
```

## 🖼 Sample Dashboard View

![Dashboard](screenshots/dashboard_view.png)

---

> Created by Arijit Malick | M.Sc. Analytics | Tata Institute of Social Sciences
